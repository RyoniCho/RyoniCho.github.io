---
title: "github 블로그 첫 포스팅"
date: 2020-06-01 15:48:00 +0900
categories: 
- Development
- etc
---

깃허브블로그에 jekyll을 활용한 블로그 포스팅 테스트입니다. `마크다운문법`을 활용해 좀 더 정돈된
글을 쓸수있습니다. 일단 테스트삼아 올려봅니다.

익숙해지는데 조금 시간이 걸리겠지만, 한번 사용해보기로!!

코드블록은 요렇게 사용한다.

***

```python

print("Hello Github Blog")

```

***

마크다운에 익숙해져야 편하게 쓰긴하겠네요!
[존크루버 마크다운번역페이지](https://nolboo.kim/blog/2013/09/07/john-gruber-markdown/)를 참고해서 공부가 필요!
